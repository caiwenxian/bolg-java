package dao.java.user;

/**
 * @Author: [caiwenxian]
 * @Date: [2018-01-16 17:45]
 * @Description: [ ]
 * @Version: [1.0.0]
 * @Copy: [com.bjike]
 */
public class IUserDao {

}
