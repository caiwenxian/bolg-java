package model.constant;

/**
 * @Author: [caiwenxian]
 * @Date: [2018-01-18 17:58]
 * @Description: [ ]
 * @Version: [1.0.0]
 * @Copy: [com.bjike]
 */
public class NetseaseUrl {

    public static final String API = "http://music.163.com";
}
