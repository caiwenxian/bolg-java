package model.constant;

/**
 * @Author: [caiwenxian]
 * @Date: [2018-01-18 17:57]
 * @Description: [ ]
 * @Version: [1.0.0]
 * @Copy: [com.bjike]
 */
public class TopListUrl {
}
